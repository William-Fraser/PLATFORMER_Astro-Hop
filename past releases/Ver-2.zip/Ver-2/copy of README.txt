To Start up
	double click the startServer.exe file (you may get a security warning that you have to allow). 
	You will see a command window appear with an IP address (for example: 192.168.1.11:8000). 
	Enter that IP address into a browser to run the game.

Controls
 	click and drag mouse to move spaceMan
	press space to use items
		use saved item : takes item from saved space (top left) and makes it active
		use active item : uses the item currently active on the player until it cannot be used, some items are passive and can only be used from it's save state